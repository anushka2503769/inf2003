import { request } from './api-client'
import type {
  CreateProfileRequest,
  MeResponse,
  Profile,
  UpdateProfileRequest,
} from '../types/api'

/**
 * Typed endpoint helpers. One function per route, grouped by feature area, so
 * that a screen never hand-writes a path or a method.
 *
 * Add new areas as flat objects here. Anything that does not exist on the
 * backend yet stays out of this file, so an import that type-checks is an
 * endpoint that is actually callable.
 */

export const profileApi = {
  /**
   * Current student's profile row.
   *
   * Throws ApiError with code 'not_found' when the student has signed in with
   * Google but has no `users` row yet; the router treats that as onboarding.
   */
  get(signal?: AbortSignal): Promise<MeResponse> {
    return request<MeResponse>('/me', { signal })
  },

  /** Creates the `users` row at the end of onboarding. */
  create(input: CreateProfileRequest, signal?: AbortSignal): Promise<MeResponse> {
    return request<MeResponse>('/me', { method: 'POST', body: input, signal })
  },

  /** Partial update; currently only the display name is editable. */
  update(input: UpdateProfileRequest, signal?: AbortSignal): Promise<Profile> {
    return request<Profile>('/me', { method: 'PATCH', body: input, signal })
  },
} as const

export const systemApi = {
  /** Liveness of the API process. Does not check database connectivity. */
  health(signal?: AbortSignal): Promise<{ status: string; service: string }> {
    return request('/health', { auth: false, signal, timeoutMs: 5_000 })
  },
} as const
